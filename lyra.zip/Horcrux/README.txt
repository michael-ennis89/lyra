  _    _                                
 | |  | |                               
 | |__| | ___  _ __ ___ _ __ _   ___  __
 |  __  |/ _ \| '__/ __| '__| | | \ \/ /
 | |  | | (_) | | | (__| |  | |_| |>  < 
 |_|  |_|\___/|_|  \___|_|   \__,_/_/\_\
                                        
-------------------------------------------------------------------
Compile Instructions:
Extract files and place the Horcrux folder on the OSU flip server.
Enter the Horcrux folder and type "make".

To run the game type Horcrux

Start New or Load a saved game.
For commands type "help", otherwise refer to Project Report.
-------------------------------------------------------------------